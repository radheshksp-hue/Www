package com.pdfmaster.app

import android.content.Context
import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.pdfmaster.app.domain.AppException
import com.pdfmaster.app.domain.PageEntry
import com.pdfmaster.app.pdf.PagePlan
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import com.pdfmaster.app.pdf.PdfEngine
import com.pdfmaster.app.storage.DocumentAccess
import com.pdfmaster.app.storage.ResultSaver
import com.pdfmaster.app.storage.TempFiles
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/**
 * Runs the real engine on real PDFs on a device or emulator. Each page of a test PDF gets a unique
 * width (200 + n), which lets the tests verify page order from the output file itself.
 */
@RunWith(AndroidJUnit4::class)
class PdfEngineInstrumentedTest {

    private lateinit var context: Context
    private lateinit var access: DocumentAccess
    private lateinit var temp: TempFiles
    private lateinit var engine: PdfEngine
    private lateinit var dir: File

    @Before
    fun setUp() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        PDFBoxResourceLoader.init(context)
        access = DocumentAccess(context)
        temp = TempFiles(context)
        engine = PdfEngine(access, temp)
        dir = File(context.cacheDir, "test-inputs").apply {
            deleteRecursively()
            mkdirs()
        }
    }

    @After
    fun tearDown() {
        dir.deleteRecursively()
    }

    // ---- helpers ----

    private fun makePdf(name: String, widths: List<Int>, rotation: Int = 0): File {
        val file = File(dir, name)
        PDDocument().use { doc ->
            widths.forEach { width ->
                val page = PDPage(PDRectangle(width.toFloat(), 300f))
                page.rotation = rotation
                doc.addPage(page)
            }
            doc.save(file)
        }
        return file
    }

    private fun info(file: File) = access.describe(Uri.fromFile(file))

    private fun widthsOf(file: File): List<Int> =
        PDDocument.load(file).use { doc -> (0 until doc.numberOfPages).map { doc.getPage(it).mediaBox.width.toInt() } }

    private fun rotationsOf(file: File): List<Int> =
        PDDocument.load(file).use { doc -> (0 until doc.numberOfPages).map { doc.getPage(it).rotation } }

    private fun expectError(kind: AppException.Kind, block: suspend () -> Unit) {
        try {
            runBlocking { block() }
            fail("Expected an AppException of kind $kind")
        } catch (e: AppException) {
            assertEquals(kind, e.kind)
        }
    }

    // ---- merge ----

    @Test
    fun mergeCombinesPagesInTheGivenOrder() = runBlocking {
        val a = makePdf("a.pdf", listOf(201, 202, 203))
        val b = makePdf("b.pdf", listOf(301, 302))

        val merged = engine.merge(listOf(info(a), info(b)), {})

        assertEquals(5, merged.pageCount)
        assertEquals(listOf(201, 202, 203, 301, 302), widthsOf(merged.file))
        assertTrue(merged.file.length() > 0)
    }

    @Test
    fun mergeRespectsReordering() = runBlocking {
        val a = makePdf("a.pdf", listOf(201))
        val b = makePdf("b.pdf", listOf(301, 302))

        val merged = engine.merge(listOf(info(b), info(a)), {})

        assertEquals(listOf(301, 302, 201), widthsOf(merged.file))
    }

    @Test
    fun mergeNeedsAtLeastTwoFiles() {
        val a = makePdf("a.pdf", listOf(201))
        expectError(AppException.Kind.INVALID_INPUT) { engine.merge(listOf(info(a)), {}) }
    }

    @Test
    fun mergeLeavesOriginalsUntouched() = runBlocking {
        val a = makePdf("a.pdf", listOf(201, 202))
        val b = makePdf("b.pdf", listOf(301))
        val sizeA = a.length()
        val sizeB = b.length()

        engine.merge(listOf(info(a), info(b)), {})

        assertEquals(sizeA, a.length())
        assertEquals(sizeB, b.length())
        assertEquals(listOf(201, 202), widthsOf(a))
    }

    @Test
    fun mergeRejectsPasswordProtectedFiles() {
        val plain = makePdf("plain.pdf", listOf(201))
        val locked = File(dir, "locked.pdf")
        PDDocument().use { doc ->
            doc.addPage(PDPage(PDRectangle(250f, 300f)))
            val policy = StandardProtectionPolicy("owner-pw", "user-pw", AccessPermission())
            policy.encryptionKeyLength = 128
            doc.protect(policy)
            doc.save(locked)
        }
        expectError(AppException.Kind.ENCRYPTED) { engine.merge(listOf(info(plain), info(locked)), {}) }
    }

    @Test
    fun mergeRejectsDamagedFiles() {
        val plain = makePdf("plain.pdf", listOf(201))
        val damaged = File(dir, "damaged.pdf").apply { writeText("this is definitely not a pdf file") }
        expectError(AppException.Kind.INVALID_PDF) { engine.merge(listOf(info(plain), info(damaged)), {}) }
    }

    @Test
    fun missingSourceIsReportedAsUnavailable() {
        val a = makePdf("a.pdf", listOf(201))
        val b = makePdf("b.pdf", listOf(301))
        val infoA = info(a)
        val infoB = info(b)
        b.delete()
        expectError(AppException.Kind.SOURCE_UNAVAILABLE) { engine.merge(listOf(infoA, infoB), {}) }
    }

    // ---- extract / split / organize ----

    @Test
    fun buildReordersAndRotatesPages() = runBlocking {
        val source = makePdf("src.pdf", listOf(201, 202, 203, 204, 205))
        val plan = PagePlan("out.pdf", listOf(PageEntry(3, 90), PageEntry(0, 0), PageEntry(3, 270)))

        val result = engine.buildDocuments(info(source), listOf(plan), {}).single()

        assertEquals(3, result.pageCount)
        assertEquals(listOf(204, 201, 204), widthsOf(result.file))
        assertEquals(listOf(90, 0, 270), rotationsOf(result.file))
    }

    @Test
    fun buildAddsToExistingPageRotation() = runBlocking {
        val source = makePdf("rotated.pdf", listOf(201, 202), rotation = 90)
        val plan = PagePlan("out.pdf", listOf(PageEntry(0, 90), PageEntry(1, 0)))

        val result = engine.buildDocuments(info(source), listOf(plan), {}).single()

        assertEquals(listOf(180, 90), rotationsOf(result.file))
    }

    @Test
    fun splitIntoIndividualPagesCreatesOneFileEach() = runBlocking {
        val source = makePdf("src.pdf", listOf(201, 202, 203))
        val plans = (0..2).map { PagePlan("page_${it + 1}.pdf", listOf(PageEntry(it, 0))) }

        val results = engine.buildDocuments(info(source), plans, {})

        assertEquals(3, results.size)
        results.forEachIndexed { index, produced ->
            assertEquals(1, produced.pageCount)
            assertEquals(listOf(201 + index), widthsOf(produced.file))
        }
    }

    @Test
    fun duplicateOutputNamesAreMadeUnique() = runBlocking {
        val source = makePdf("src.pdf", listOf(201, 202))
        val plans = listOf(
            PagePlan("same.pdf", listOf(PageEntry(0, 0))),
            PagePlan("same.pdf", listOf(PageEntry(1, 0))),
        )

        val results = engine.buildDocuments(info(source), plans, {})

        assertEquals(2, results.map { it.displayName }.toSet().size)
    }

    @Test
    fun buildRejectsPagesThatDoNotExist() {
        val source = makePdf("src.pdf", listOf(201, 202))
        val plan = PagePlan("out.pdf", listOf(PageEntry(5, 0)))
        expectError(AppException.Kind.INVALID_INPUT) { engine.buildDocuments(info(source), listOf(plan), {}) }
    }

    @Test
    fun buildRejectsEmptyPlans() {
        val source = makePdf("src.pdf", listOf(201))
        expectError(AppException.Kind.INVALID_INPUT) {
            engine.buildDocuments(info(source), listOf(PagePlan("out.pdf", emptyList())), {})
        }
    }

    @Test
    fun progressIsReportedWithRealStepCounts() = runBlocking {
        val source = makePdf("src.pdf", listOf(201, 202, 203))
        val plans = (0..2).map { PagePlan("p$it.pdf", listOf(PageEntry(it, 0))) }
        val reports = mutableListOf<Pair<Int, Int>>()

        engine.buildDocuments(info(source), plans, { reports += it.done to it.total })

        assertTrue(reports.isNotEmpty())
        assertTrue(reports.all { (done, total) -> done in 0..total })
        assertEquals(4, reports.last().second)
    }

    // ---- renderer ----

    @Test
    fun rendererOpensPagesAndProducesBitmaps() = runBlocking {
        val file = makePdf("view.pdf", listOf(201, 202, 203))

        PdfDocumentRenderer.open(context, access, temp, Uri.fromFile(file)).use { renderer ->
            assertEquals(3, renderer.pageCount)
            assertEquals(3, renderer.pageSizes.size)
            val bitmap = renderer.render(0, 300)
            assertEquals(300, bitmap.width)
            assertTrue(bitmap.height > 0)
        }
    }

    @Test
    fun renderingAfterCloseIsCancelledNotCrashed() = runBlocking {
        val file = makePdf("view.pdf", listOf(201))
        val renderer = PdfDocumentRenderer.open(context, access, temp, Uri.fromFile(file))
        renderer.close()
        try {
            renderer.render(0, 200)
            fail("Expected rendering to be cancelled")
        } catch (expected: CancellationException) {
            // Closed documents refuse to render.
        }
    }

    @Test
    fun rendererReportsDamagedFiles() {
        val damaged = File(dir, "damaged.pdf").apply { writeText("not a pdf") }
        expectError(AppException.Kind.INVALID_PDF) {
            PdfDocumentRenderer.open(context, access, temp, Uri.fromFile(damaged))
        }
    }

    // ---- saving ----

    @Test
    fun savedCopyIsVerifiedAndIdentical() = runBlocking {
        val source = makePdf("src.pdf", listOf(201, 202))
        val produced = engine.buildDocuments(
            info(source),
            listOf(PagePlan("out.pdf", listOf(PageEntry(1, 0)))),
            {},
        ).single()
        val destination = File(dir, "saved.pdf")

        val saved = ResultSaver(access).saveSingle(produced.file, Uri.fromFile(destination))

        assertEquals(produced.file.length(), saved.sizeBytes)
        assertArrayEquals(produced.file.readBytes(), destination.readBytes())
    }
}

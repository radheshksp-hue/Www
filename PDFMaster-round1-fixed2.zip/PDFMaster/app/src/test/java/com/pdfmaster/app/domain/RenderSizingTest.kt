package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RenderSizingTest {

    @Test
    fun keepsAspectRatioForNormalRequests() {
        val (w, h) = RenderSizing.fit(pageWidth = 600, pageHeight = 800, requestedWidth = 300)
        assertEquals(300, w)
        assertEquals(400, h)
    }

    @Test
    fun capsTheWidth() {
        val (w, _) = RenderSizing.fit(600, 800, 100_000)
        assertTrue(w <= RenderSizing.MAX_WIDTH)
    }

    @Test
    fun capsTheTotalPixelCount() {
        val (w, h) = RenderSizing.fit(pageWidth = 100, pageHeight = 10_000, requestedWidth = 2400)
        assertTrue(w.toLong() * h <= RenderSizing.MAX_PIXELS.toLong() + w)
    }

    @Test
    fun neverReturnsZeroSizes() {
        val (w, h) = RenderSizing.fit(pageWidth = 0, pageHeight = 0, requestedWidth = 0)
        assertTrue(w >= 1 && h >= 1)
    }
}

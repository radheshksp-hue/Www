package com.pdfmaster.app.ui.home

import android.net.Uri
import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.RecentFile
import com.pdfmaster.app.domain.RecentFilesLogic
import com.pdfmaster.app.domain.RecentSort
import com.pdfmaster.app.domain.SizeFormat
import com.pdfmaster.app.ui.components.EmptyState
import com.pdfmaster.app.ui.components.SectionHeader
import com.pdfmaster.app.ui.components.ToolCard

@Composable
fun HomeScreen(
    container: AppContainer,
    onOpenPdf: (Uri) -> Unit,
    onOpenTool: (PdfTool, Uri?) -> Unit,
    onOpenSettings: () -> Unit,
) {
    val viewModel: HomeViewModel = viewModel(
        factory = viewModelFactory { initializer { HomeViewModel(container) } },
    )
    val recents by viewModel.recents.collectAsStateWithLifecycle()

    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf(RecentSort.DATE) }
    var pendingTool by rememberSaveable { mutableStateOf<PdfTool?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val tool = pendingTool
        pendingTool = null
        if (uri != null) {
            viewModel.keepAccess(uri)
            if (tool == null) onOpenPdf(uri) else onOpenTool(tool, uri)
        }
    }

    fun pickPdf(forTool: PdfTool?) {
        pendingTool = forTool
        picker.launch(arrayOf("application/pdf"))
    }

    val visibleTools = remember(query) {
        PdfTool.entries.filter {
            query.isBlank() ||
                it.title.contains(query.trim(), ignoreCase = true) ||
                it.description.contains(query.trim(), ignoreCase = true)
        }
    }
    val visibleRecents = remember(recents, query, sort) {
        RecentFilesLogic.filterAndSort(recents.orEmpty(), query, sort)
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Header(onOpenSettings) }

            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search tools and recent files") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                )
            }

            item {
                Button(
                    onClick = { pickPdf(null) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                ) {
                    Icon(Icons.Filled.FileOpen, contentDescription = null, modifier = Modifier.size(22.dp))
                    Text("  Open a PDF", style = MaterialTheme.typography.titleSmall)
                }
            }

            ToolCategoryOrder.forEach { category ->
                val tools = visibleTools.filter { it.category == category }
                if (tools.isNotEmpty()) {
                    item(key = "category-${category.name}") { SectionHeader(category.title) }
                    items(tools.chunked(2), key = { row -> row.joinToString { it.name } }) { rowTools ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            rowTools.forEach { tool ->
                                ToolCard(
                                    tool = tool,
                                    onClick = {
                                        if (tool.needsFile) pickPdf(tool) else onOpenTool(tool, null)
                                    },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            if (rowTools.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            if (visibleTools.isEmpty() && query.isNotBlank()) {
                item { Text("No tools match \"${query.trim()}\".", style = MaterialTheme.typography.bodyMedium) }
            }

            item(key = "recent-header") {
                SectionHeader(
                    title = "Recent files",
                    trailing = { SortMenu(sort) { sort = it } },
                )
            }

            val list = recents
            when {
                list == null -> Unit
                list.isEmpty() -> item(key = "recent-empty") {
                    EmptyState(
                        icon = Icons.Filled.PictureAsPdf,
                        title = "No recent files yet",
                        message = "PDFs you open or save appear here for quick access.",
                    )
                }

                visibleRecents.isEmpty() -> item(key = "recent-none") {
                    Text("No recent files match \"${query.trim()}\".", style = MaterialTheme.typography.bodyMedium)
                }

                else -> items(visibleRecents, key = { it.uri }) { file ->
                    RecentRow(
                        file = file,
                        onClick = { onOpenPdf(Uri.parse(file.uri)) },
                        onRemove = { viewModel.removeFromRecents(file) },
                    )
                }
            }
        }
    }
}

private val ToolCategoryOrder = ToolCategory.entries

@Composable
private fun Header(onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(44.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Filled.PictureAsPdf,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(26.dp),
                )
            }
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text("PDF Master", style = MaterialTheme.typography.titleLarge)
            Text(
                "Your PDF tools, on your device",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Filled.Settings, contentDescription = "Settings")
        }
    }
}

@Composable
private fun SortMenu(current: RecentSort, onSelect: (RecentSort) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { expanded = true }) { Text("Sort: ${current.label}") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            RecentSort.entries.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.label) },
                    onClick = {
                        expanded = false
                        onSelect(option)
                    },
                )
            }
        }
    }
}

@Composable
private fun RecentRow(
    file: RecentFile,
    onClick: () -> Unit,
    onRemove: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = {
            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        headlineContent = { Text(file.name, maxLines = 1) },
        supportingContent = {
            val opened = DateUtils.getRelativeTimeSpanString(
                file.openedAtMillis,
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS,
            )
            Text("${SizeFormat.format(file.sizeBytes)} · opened $opened")
        },
        trailingContent = {
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "More options for ${file.name}")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Remove from recent files") },
                        onClick = {
                            menuOpen = false
                            onRemove()
                        },
                    )
                }
            }
        },
    )
}

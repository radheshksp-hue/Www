package com.pdfmaster.app.ui.settings

/** Plain-language privacy summary shown in the app. The full text lives in PRIVACY.md. */
object PrivacyText {
    const val SUMMARY =
        "PDF Master processes your documents on your device. Files are never uploaded, " +
            "and this version contains no ads, analytics or network features.\n\n" +
            "• Files are opened only through the system file picker; the app has no broad storage permission.\n" +
            "• The app keeps a list of recently opened files (name, size, time) and the theme you chose, on this device only.\n" +
            "• While a tool runs, temporary copies are made in the app's private cache and deleted afterwards. " +
            "Finished results wait in the cache until you save or discard them, and stale ones are removed automatically.\n" +
            "• Your original files are never modified.\n" +
            "• Document contents, names and passwords are not written to logs."
}

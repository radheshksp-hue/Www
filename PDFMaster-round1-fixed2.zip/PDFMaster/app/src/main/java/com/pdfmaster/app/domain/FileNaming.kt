package com.pdfmaster.app.domain

import java.util.Locale

object FileNaming {
    private const val MAX_STEM_LENGTH = 100
    private val illegalCharacters = Regex("""[\\/:*?"<>|\u0000-\u001F]""")

    /** Removes characters that file systems and document providers reject. Never returns empty. */
    fun sanitize(name: String): String {
        val cleaned = name.replace(illegalCharacters, "_").trim().trim('.').trim()
        return cleaned.ifEmpty { "document" }
    }

    /** The file name without a trailing `.pdf`, sanitized and length-limited. */
    fun stem(fileName: String): String {
        val clean = sanitize(fileName)
        val withoutExtension =
            if (clean.length > 4 && clean.endsWith(".pdf", ignoreCase = true)) clean.dropLast(4).trimEnd() else clean
        return withoutExtension.take(MAX_STEM_LENGTH).ifEmpty { "document" }
    }

    /** `report.pdf` + `pages_1-3` -> `report_pages_1-3.pdf`. */
    fun outputName(sourceName: String, suffix: String): String =
        "${stem(sourceName)}_${sanitize(suffix)}.pdf"

    /**
     * Returns [desired] if it is free, otherwise `name (1).ext`, `name (2).ext`, ...
     * Comparison ignores case because many providers do.
     */
    fun uniqueName(desired: String, existing: Collection<String>): String {
        val taken = existing.map { it.lowercase(Locale.ROOT) }.toSet()
        if (desired.lowercase(Locale.ROOT) !in taken) return desired

        val dot = desired.lastIndexOf('.')
        val base = if (dot > 0) desired.substring(0, dot) else desired
        val extension = if (dot > 0) desired.substring(dot) else ""
        return generateSequence(1) { it + 1 }
            .map { "$base ($it)$extension" }
            .first { it.lowercase(Locale.ROOT) !in taken }
    }
}

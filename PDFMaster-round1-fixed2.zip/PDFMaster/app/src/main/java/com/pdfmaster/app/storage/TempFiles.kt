package com.pdfmaster.app.storage

import android.content.Context
import java.io.File
import java.util.UUID

/**
 * All scratch data lives under the app cache directory:
 *  - work/<id>/        copies of inputs while an operation runs (deleted right afterwards)
 *  - results/<id>/     verified outputs waiting to be saved or shared (deleted when stale)
 *  - pdfbox-scratch/   PDFBox's own spill files
 */
class TempFiles(private val context: Context) {

    private val workRoot: File get() = File(context.cacheDir, "work")
    private val resultsRoot: File get() = File(context.cacheDir, "results")
    private val scratchRoot: File get() = File(context.cacheDir, "pdfbox-scratch")

    fun newWorkDir(): File = newDir(workRoot)

    fun newResultDir(): File = newDir(resultsRoot)

    fun scratchDir(): File = scratchRoot.apply { mkdirs() }

    /** Called at app start. Leftovers from a crash or a killed process are removed here. */
    fun cleanStale(maxResultAgeMillis: Long = 24L * 60 * 60 * 1000) {
        workRoot.deleteRecursively()
        scratchRoot.deleteRecursively()
        val now = System.currentTimeMillis()
        resultsRoot.listFiles()?.forEach { dir ->
            if (now - dir.lastModified() > maxResultAgeMillis) dir.deleteRecursively()
        }
    }

    private fun newDir(root: File): File {
        val dir = File(root, UUID.randomUUID().toString())
        check(dir.mkdirs() || dir.isDirectory) { "Could not create a temporary folder" }
        return dir
    }
}

package com.pdfmaster.app.domain

sealed interface RangeParseResult {
    /** Ranges are 1-based and inclusive, in the order the user typed them. */
    data class Success(val ranges: List<IntRange>) : RangeParseResult
    data class Error(val message: String) : RangeParseResult
}

object PageRanges {

    /**
     * Parses text such as `1-3, 5, 8-` (open end = last page) or `-4` (from page 1).
     */
    fun parse(input: String, pageCount: Int): RangeParseResult {
        if (pageCount <= 0) return RangeParseResult.Error("The document has no pages.")
        val text = input.trim()
        if (text.isEmpty()) {
            return RangeParseResult.Error("Enter at least one page or range, for example 1-3, 5.")
        }

        val ranges = mutableListOf<IntRange>()
        for (raw in text.split(',')) {
            val token = raw.filterNot { it.isWhitespace() }
            if (token.isEmpty()) {
                return RangeParseResult.Error("Remove the extra comma: one of the entries is empty.")
            }

            val dashAt = token.indexOf('-')
            val start: Int
            val end: Int
            if (dashAt < 0) {
                val page = parsePage(token) ?: return invalid(token)
                start = page
                end = page
            } else {
                if (token.indexOf('-', dashAt + 1) >= 0) return invalid(token)
                val left = token.substring(0, dashAt)
                val right = token.substring(dashAt + 1)
                if (left.isEmpty() && right.isEmpty()) return invalid(token)
                start = if (left.isEmpty()) 1 else (parsePage(left) ?: return invalid(token))
                end = if (right.isEmpty()) pageCount else (parsePage(right) ?: return invalid(token))
            }

            if (start < 1 || end < 1) {
                return RangeParseResult.Error("Page numbers start at 1.")
            }
            if (start > pageCount || end > pageCount) {
                val offending = maxOf(start, end)
                return RangeParseResult.Error(
                    "Page $offending is outside this document, which has $pageCount ${pages(pageCount)}.",
                )
            }
            if (start > end) {
                return RangeParseResult.Error(
                    "\"$token\" runs backwards. Write the lower page number first.",
                )
            }
            ranges += start..end
        }
        return RangeParseResult.Success(ranges)
    }

    /** Flattens ranges into the list of 1-based page numbers, keeping the typed order. */
    fun expand(ranges: List<IntRange>): List<Int> = ranges.flatMap { it.toList() }

    fun label(range: IntRange): String =
        if (range.first == range.last) "${range.first}" else "${range.first}-${range.last}"

    private fun parsePage(text: String): Int? =
        if (text.isNotEmpty() && text.length <= 9 && text.all { it in '0'..'9' }) text.toIntOrNull() else null

    private fun invalid(token: String): RangeParseResult.Error =
        RangeParseResult.Error("\"$token\" is not a valid page or range. Use numbers like 3 or 2-5.")

    private fun pages(count: Int) = if (count == 1) "page" else "pages"
}

package com.pdfmaster.app.ui.home

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.ui.graphics.vector.ImageVector

enum class ToolCategory(val title: String) {
    ORGANIZE("Organize"),
}

/** Only tools that are fully implemented are listed here; unfinished ones stay out of the UI. */
enum class PdfTool(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val category: ToolCategory,
    /** True when the tool starts by asking for one PDF through the document picker. */
    val needsFile: Boolean,
) {
    MERGE(
        title = "Merge PDFs",
        description = "Combine several files into one",
        icon = Icons.Filled.MergeType,
        category = ToolCategory.ORGANIZE,
        needsFile = false,
    ),
    SPLIT(
        title = "Split & extract",
        description = "Pull out pages or ranges",
        icon = Icons.Filled.CallSplit,
        category = ToolCategory.ORGANIZE,
        needsFile = true,
    ),
    ORGANIZE(
        title = "Organize pages",
        description = "Reorder, rotate, delete",
        icon = Icons.Filled.GridView,
        category = ToolCategory.ORGANIZE,
        needsFile = true,
    ),
}

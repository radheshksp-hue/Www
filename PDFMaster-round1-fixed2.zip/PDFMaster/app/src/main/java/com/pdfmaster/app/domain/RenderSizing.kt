package com.pdfmaster.app.domain

import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Keeps page bitmaps inside sane memory limits no matter how large the zoom or the page. */
object RenderSizing {
    const val MIN_WIDTH = 16
    const val MAX_WIDTH = 2400
    const val MAX_PIXELS = 9_000_000.0

    /** @return width and height in pixels for a page of [pageWidth] x [pageHeight] points. */
    fun fit(pageWidth: Int, pageHeight: Int, requestedWidth: Int): Pair<Int, Int> {
        val safeWidth = max(pageWidth, 1)
        val safeHeight = max(pageHeight, 1)
        var width = requestedWidth.coerceIn(MIN_WIDTH, MAX_WIDTH).toDouble()
        var height = width * safeHeight / safeWidth
        val pixels = width * height
        if (pixels > MAX_PIXELS) {
            val scale = sqrt(MAX_PIXELS / pixels)
            width *= scale
            height *= scale
        }
        return Pair(max(1, width.roundToInt()), max(1, height.roundToInt()))
    }
}

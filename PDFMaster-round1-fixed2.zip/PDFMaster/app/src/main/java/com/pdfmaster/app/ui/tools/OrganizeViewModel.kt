package com.pdfmaster.app.ui.tools

import android.net.Uri
import androidx.lifecycle.viewModelScope
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.ErrorMessages
import com.pdfmaster.app.domain.FileNaming
import com.pdfmaster.app.domain.PageEditorState
import com.pdfmaster.app.domain.PageEntry
import com.pdfmaster.app.domain.PageItem
import com.pdfmaster.app.pdf.PageBitmapCache
import com.pdfmaster.app.pdf.PagePlan
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import com.pdfmaster.app.storage.DocumentInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface OrganizeLoad {
    data object Loading : OrganizeLoad
    data class Ready(val renderer: PdfDocumentRenderer, val info: DocumentInfo) : OrganizeLoad
    data class Error(val message: String) : OrganizeLoad
}

class OrganizeViewModel(container: AppContainer, private val uri: Uri) : ToolViewModel(container) {

    private val _load = MutableStateFlow<OrganizeLoad>(OrganizeLoad.Loading)
    val load: StateFlow<OrganizeLoad> = _load.asStateFlow()

    private val _editor = MutableStateFlow(PageEditorState.initial(0))
    val editor: StateFlow<PageEditorState> = _editor.asStateFlow()

    val cache: PageBitmapCache = PageBitmapCache.createDefault()

    init {
        viewModelScope.launch {
            try {
                val info = container.access.describe(uri)
                val renderer = PdfDocumentRenderer.open(container.appContext, container.access, container.temp, uri)
                _editor.value = PageEditorState.initial(renderer.pageCount)
                _load.value = OrganizeLoad.Ready(renderer, info)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _load.value = OrganizeLoad.Error(ErrorMessages.describe(e))
            }
        }
    }

    fun toggle(id: Long) = _editor.update { it.toggle(id) }
    fun selectAll() = _editor.update { it.selectAll() }
    fun clearSelection() = _editor.update { it.clearSelection() }
    fun selectOdd() = _editor.update { it.selectOdd() }
    fun selectEven() = _editor.update { it.selectEven() }
    fun rotate(degrees: Int) = _editor.update { it.rotateSelected(degrees) }
    fun deleteSelected() = _editor.update { it.deleteSelected() }
    fun move(direction: Int) = _editor.update { it.moveSelected(direction) }
    fun duplicateSelected() = _editor.update { it.duplicateSelected() }
    fun reverse() = _editor.update { it.reverse() }
    fun undo() = _editor.update { it.undo() }
    fun redo() = _editor.update { it.redo() }

    /** Saves every page in its current order and rotation as a new PDF. */
    fun saveAll() = startSave(_editor.value.pages, "organized")

    /** Saves only the selected pages, in their current order, as a new PDF. */
    fun saveSelected() = startSave(_editor.value.selectedPages, "selected")

    private fun startSave(pages: List<PageItem>, suffix: String) {
        val ready = _load.value as? OrganizeLoad.Ready ?: return
        if (pages.isEmpty()) return
        val plan = PagePlan(
            fileName = FileNaming.outputName(ready.info.displayName, suffix),
            entries = pages.map { PageEntry(it.sourceIndex, it.rotation) },
        )
        startProcessing { report -> container.engine.buildDocuments(ready.info, listOf(plan), report) }
    }

    override fun onCleared() {
        (_load.value as? OrganizeLoad.Ready)?.renderer?.close()
        cache.clear()
        super.onCleared()
    }
}

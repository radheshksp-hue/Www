package com.pdfmaster.app.ui.tools

import android.net.Uri
import androidx.lifecycle.viewModelScope
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.ErrorMessages
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import com.pdfmaster.app.storage.DocumentInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** A file in the merge list. [error] is set when the file can't be merged (protected, damaged, gone). */
data class MergeItem(
    val id: Long,
    val info: DocumentInfo,
    val pageCount: Int?,
    val error: String?,
)

class MergeViewModel(container: AppContainer) : ToolViewModel(container) {

    private val _items = MutableStateFlow<List<MergeItem>>(emptyList())
    val items: StateFlow<List<MergeItem>> = _items.asStateFlow()

    private val _checking = MutableStateFlow(false)
    val checking: StateFlow<Boolean> = _checking.asStateFlow()

    private var nextId = 0L

    /** Adds the picked files and checks each one right away so problems show up before merging. */
    fun addDocuments(uris: List<Uri>) {
        if (uris.isEmpty() || _checking.value) return
        _checking.value = true
        viewModelScope.launch {
            try {
                val added = uris.map { uri ->
                    container.access.persistRead(uri)
                    probe(uri, nextId++)
                }
                _items.update { it + added }
            } finally {
                _checking.value = false
            }
        }
    }

    fun move(index: Int, delta: Int) {
        _items.update { list ->
            val target = index + delta
            if (index !in list.indices || target !in list.indices) {
                list
            } else {
                list.toMutableList().apply {
                    val item = removeAt(index)
                    add(target, item)
                }
            }
        }
    }

    fun remove(index: Int) {
        _items.update { list -> if (index in list.indices) list.filterIndexed { i, _ -> i != index } else list }
    }

    fun canMerge(items: List<MergeItem>, checking: Boolean): Boolean =
        !checking && items.size >= 2 && items.all { it.error == null }

    fun merge() {
        val valid = _items.value
        if (!canMerge(valid, _checking.value)) return
        val sources = valid.map { it.info }
        startProcessing { report ->
            listOf(container.engine.merge(sources, report))
        }
    }

    private suspend fun probe(uri: Uri, id: Long): MergeItem {
        return try {
            val info = container.access.describe(uri)
            PdfDocumentRenderer.open(
                container.appContext,
                container.access,
                container.temp,
                uri,
                withPageSizes = false,
            ).use { MergeItem(id, info, it.pageCount, null) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            MergeItem(
                id = id,
                info = DocumentInfo(uri, uri.lastPathSegment?.substringAfterLast('/') ?: "Unknown file", -1L),
                pageCount = null,
                error = ErrorMessages.describe(e),
            )
        }
    }
}

package com.pdfmaster.app.pdf

import com.pdfmaster.app.domain.PageEntry
import java.io.File

/** A verified output file waiting in the cache until the user saves or shares it. */
data class ProducedFile(
    val file: File,
    val displayName: String,
    val pageCount: Int,
) {
    val sizeBytes: Long get() = file.length()
}

/** One output document to build: its file name and the pages (in order) it should contain. */
data class PagePlan(
    val fileName: String,
    val entries: List<PageEntry>,
)

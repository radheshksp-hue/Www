package com.pdfmaster.app.ui.tools

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfmaster.app.domain.OperationState
import com.pdfmaster.app.domain.SizeFormat
import com.pdfmaster.app.pdf.ProducedFile
import com.pdfmaster.app.ui.components.MessageCard
import com.pdfmaster.app.ui.components.ProgressCard
import com.pdfmaster.app.ui.util.Intents

/**
 * The result area shared by every tool: progress, errors, the verified result and its save options.
 * Success is only shown after the engine has re-opened and checked the output.
 */
@Composable
fun ToolOutput(
    viewModel: ToolViewModel,
    onOpenPdf: (Uri) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val processing by viewModel.processing.state.collectAsStateWithLifecycle()
    val saving by viewModel.saving.state.collectAsStateWithLifecycle()

    val createDocument = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf"),
    ) { uri -> if (uri != null) viewModel.saveToDocument(uri) }

    val pickFolder = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { uri -> if (uri != null) viewModel.saveToFolder(uri) }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (val state = processing) {
            OperationState.Idle -> Unit

            is OperationState.Running -> ProgressCard(
                label = state.progress?.label ?: "Working…",
                fraction = state.progress?.fraction,
                onCancel = viewModel::cancelProcessing,
            )

            is OperationState.Failed -> MessageCard(
                message = state.message,
                isError = true,
                onDismiss = viewModel::dismissProcessing,
            )

            OperationState.Cancelled -> MessageCard(
                message = "Cancelled. Nothing was saved and your original files are unchanged.",
                onDismiss = viewModel::dismissProcessing,
            )

            is OperationState.Completed -> {
                val files = state.result
                ResultCard(
                    files = files,
                    saveEnabled = saving !is OperationState.Running,
                    onSave = {
                        if (files.size == 1) createDocument.launch(files.first().displayName)
                        else pickFolder.launch(null)
                    },
                    onShare = {
                        Intents.sharePdfs(context, files.map { Intents.resultUri(context, it.file) })
                    },
                    onOpen = if (files.size == 1) {
                        { onOpenPdf(Intents.resultUri(context, files.first().file)) }
                    } else null,
                    onDiscard = viewModel::discardResult,
                )

                when (val save = saving) {
                    OperationState.Idle -> Unit

                    is OperationState.Running -> ProgressCard(
                        label = save.progress?.label ?: "Saving…",
                        fraction = save.progress?.fraction,
                        onCancel = viewModel::cancelSaving,
                    )

                    is OperationState.Failed -> MessageCard(
                        message = save.message,
                        isError = true,
                        onDismiss = viewModel::dismissSaving,
                    )

                    OperationState.Cancelled -> MessageCard(
                        message = "Saving was cancelled. The result is still ready if you want to save it again.",
                        onDismiss = viewModel::dismissSaving,
                    )

                    is OperationState.Completed -> SavedCard(
                        saved = save.result,
                        onOpen = if (save.result.size == 1) {
                            { onOpenPdf(save.result.first().uri) }
                        } else null,
                    )
                }
            }
        }
    }
}

@Composable
private fun ResultCard(
    files: List<ProducedFile>,
    saveEnabled: Boolean,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onOpen: (() -> Unit)?,
    onDiscard: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = if (files.size == 1) "Your PDF is ready" else "${files.size} PDFs are ready",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Text(
                text = "Checked after creation. Not saved yet: choose where to keep it.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            files.take(MAX_LISTED).forEach { file ->
                Text(
                    text = "${file.displayName} · ${file.pageCount} ${if (file.pageCount == 1) "page" else "pages"} · " +
                        SizeFormat.format(file.sizeBytes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                )
            }
            if (files.size > MAX_LISTED) {
                Text(
                    text = "and ${files.size - MAX_LISTED} more",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                )
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Button(onClick = onSave, enabled = saveEnabled) {
                    Text(if (files.size == 1) "Save to…" else "Save to folder…")
                }
                OutlinedButton(onClick = onShare) { Text("Share") }
                if (onOpen != null) OutlinedButton(onClick = onOpen) { Text("Preview") }
                TextButton(onClick = onDiscard, enabled = saveEnabled) { Text("Discard") }
            }
        }
    }
}

@Composable
private fun SavedCard(
    saved: List<com.pdfmaster.app.storage.SavedFile>,
    onOpen: (() -> Unit)?,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (saved.size == 1) "Saved and checked" else "${saved.size} files saved and checked",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            saved.take(MAX_LISTED).forEach {
                Text(
                    text = "${it.name} · ${SizeFormat.format(it.sizeBytes)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
            saved.firstOrNull()?.let {
                Text(
                    text = "Location: ${it.location}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
            if (onOpen != null) {
                OutlinedButton(onClick = onOpen) { Text("Open saved file") }
            }
        }
    }
}

private const val MAX_LISTED = 5

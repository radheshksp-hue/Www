package com.pdfmaster.app.ui.reader

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.AppException
import com.pdfmaster.app.domain.ErrorMessages
import com.pdfmaster.app.pdf.PageBitmapCache
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import com.pdfmaster.app.storage.DocumentInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface ReaderUiState {
    data object Loading : ReaderUiState
    data class Ready(val renderer: PdfDocumentRenderer, val info: DocumentInfo) : ReaderUiState
    data class Error(val message: String, val canRemoveFromRecents: Boolean) : ReaderUiState
}

class ReaderViewModel(
    private val container: AppContainer,
    private val uri: Uri,
) : ViewModel() {

    private val _state = MutableStateFlow<ReaderUiState>(ReaderUiState.Loading)
    val state: StateFlow<ReaderUiState> = _state.asStateFlow()

    val cache: PageBitmapCache = PageBitmapCache.createDefault()

    init {
        viewModelScope.launch {
            try {
                val info = container.access.describe(uri)
                val renderer = PdfDocumentRenderer.open(container.appContext, container.access, container.temp, uri)
                _state.value = ReaderUiState.Ready(renderer, info)
                // Results from the cache folder are previews, not documents worth remembering.
                if (uri.authority != "${container.appContext.packageName}.fileprovider") {
                    container.rememberDocument(info)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                val gone = e is AppException && e.kind == AppException.Kind.SOURCE_UNAVAILABLE
                _state.value = ReaderUiState.Error(ErrorMessages.describe(e), canRemoveFromRecents = gone)
            }
        }
    }

    fun removeFromRecents() {
        viewModelScope.launch {
            container.recents.remove(uri.toString())
            container.access.releaseRead(uri)
        }
    }

    override fun onCleared() {
        (_state.value as? ReaderUiState.Ready)?.renderer?.close()
        cache.clear()
        super.onCleared()
    }
}

package com.pdfmaster.app.domain

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Runs one long operation at a time and exposes its lifecycle as [OperationState].
 *
 * - A second [start] while running is ignored (protects against double taps).
 * - [cancel] moves the state to [OperationState.Cancelled].
 * - Failures never escape; they become [OperationState.Failed] with a readable message.
 */
class OperationRunner<T>(private val scope: CoroutineScope) {

    private val _state = MutableStateFlow<OperationState<T>>(OperationState.Idle)
    val state: StateFlow<OperationState<T>> = _state.asStateFlow()

    private var job: Job? = null

    val isRunning: Boolean get() = _state.value is OperationState.Running

    /** @return false when an operation is already running and nothing was started. */
    fun start(block: suspend (report: (OperationProgress) -> Unit) -> T): Boolean {
        if (isRunning) return false
        _state.value = OperationState.Running()
        val launched = scope.launch {
            try {
                val result = block { progress ->
                    _state.update { current ->
                        if (current is OperationState.Running) OperationState.Running(progress) else current
                    }
                }
                _state.value = OperationState.Completed(result)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _state.value = OperationState.Failed(ErrorMessages.describe(e))
            }
        }
        launched.invokeOnCompletion { cause ->
            if (cause != null) {
                _state.update { current ->
                    if (current is OperationState.Running) OperationState.Cancelled else current
                }
            }
        }
        job = launched
        return true
    }

    fun cancel() {
        job?.cancel()
    }

    /** Returns to [OperationState.Idle] unless an operation is currently running. */
    fun reset() {
        if (!isRunning) _state.value = OperationState.Idle
    }
}

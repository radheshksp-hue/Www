package com.pdfmaster.app.ui.tools

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.OperationProgress
import com.pdfmaster.app.domain.OperationRunner
import com.pdfmaster.app.domain.OperationState
import com.pdfmaster.app.pdf.ProducedFile
import com.pdfmaster.app.storage.DocumentInfo
import com.pdfmaster.app.storage.SavedFile

/**
 * Shared life cycle of every tool: process into the cache (verified), then save/share/open/discard.
 * [processing] and [saving] each run at most one job at a time.
 */
abstract class ToolViewModel(protected val container: AppContainer) : ViewModel() {

    val processing = OperationRunner<List<ProducedFile>>(viewModelScope)
    val saving = OperationRunner<List<SavedFile>>(viewModelScope)

    private fun produced(): List<ProducedFile>? =
        (processing.state.value as? OperationState.Completed)?.result

    protected fun startProcessing(
        block: suspend (report: (OperationProgress) -> Unit) -> List<ProducedFile>,
    ) {
        if (processing.isRunning) return
        deleteProduced()
        saving.reset()
        processing.start(block)
    }

    fun saveToDocument(destination: Uri) {
        val file = produced()?.singleOrNull() ?: return
        saving.start { _ ->
            val saved = container.resultSaver.saveSingle(file.file, destination)
            container.rememberDocument(DocumentInfo(saved.uri, saved.name, saved.sizeBytes))
            listOf(saved)
        }
    }

    fun saveToFolder(folder: Uri) {
        val files = produced() ?: return
        saving.start { report -> container.resultSaver.saveMany(files, folder, report) }
    }

    fun cancelProcessing() = processing.cancel()

    fun cancelSaving() = saving.cancel()

    fun dismissProcessing() = processing.reset()

    fun dismissSaving() = saving.reset()

    /** Throws away the cached result files and returns to the idle state. */
    fun discardResult() {
        if (saving.isRunning) return
        deleteProduced()
        saving.reset()
        processing.reset()
    }

    private fun deleteProduced() {
        produced()?.forEach { it.file.parentFile?.deleteRecursively() }
    }
}

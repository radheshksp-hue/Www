package com.pdfmaster.app.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.UriArg
import com.pdfmaster.app.ui.home.HomeScreen
import com.pdfmaster.app.ui.home.PdfTool
import com.pdfmaster.app.ui.reader.ReaderScreen
import com.pdfmaster.app.ui.settings.SettingsScreen
import com.pdfmaster.app.ui.tools.MergeScreen
import com.pdfmaster.app.ui.tools.OrganizeScreen
import com.pdfmaster.app.ui.tools.SplitScreen

@Composable
fun AppNavHost(
    container: AppContainer,
    incomingUri: Uri?,
    onIncomingHandled: () -> Unit,
) {
    val navController = rememberNavController()

    // A PDF opened from another app ("Open with PDF Master").
    LaunchedEffect(incomingUri) {
        if (incomingUri != null) {
            navController.navigate(Routes.reader(incomingUri))
            onIncomingHandled()
        }
    }

    val uriArgument = listOf(navArgument(Routes.ARG) { type = NavType.StringType })

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                container = container,
                onOpenPdf = { navController.safeNavigate(Routes.reader(it)) },
                onOpenTool = { tool, uri ->
                    when (tool) {
                        PdfTool.MERGE -> navController.safeNavigate(Routes.MERGE)
                        PdfTool.SPLIT -> if (uri != null) navController.safeNavigate(Routes.split(uri))
                        PdfTool.ORGANIZE -> if (uri != null) navController.safeNavigate(Routes.organize(uri))
                    }
                },
                onOpenSettings = { navController.safeNavigate(Routes.SETTINGS) },
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(container = container, onBack = { navController.safePop() })
        }

        composable(Routes.MERGE) {
            MergeScreen(
                container = container,
                onBack = { navController.safePop() },
                onOpenPdf = { navController.safeNavigate(Routes.reader(it)) },
            )
        }

        composable(Routes.READER, arguments = uriArgument) { entry ->
            ReaderScreen(
                container = container,
                uri = entry.documentUri(),
                onBack = { navController.safePop() },
            )
        }

        composable(Routes.SPLIT, arguments = uriArgument) { entry ->
            SplitScreen(
                container = container,
                uri = entry.documentUri(),
                onBack = { navController.safePop() },
                onOpenPdf = { navController.safeNavigate(Routes.reader(it)) },
            )
        }

        composable(Routes.ORGANIZE, arguments = uriArgument) { entry ->
            OrganizeScreen(
                container = container,
                uri = entry.documentUri(),
                onBack = { navController.safePop() },
                onOpenPdf = { navController.safeNavigate(Routes.reader(it)) },
            )
        }
    }
}

private fun NavBackStackEntry.documentUri(): Uri =
    Uri.parse(UriArg.decode(requireNotNull(arguments?.getString(Routes.ARG)) { "Missing document argument" }))

/** Ignores taps that arrive while a screen is already transitioning, which prevents duplicate screens. */
private fun NavController.safeNavigate(route: String) {
    if (currentBackStackEntry?.lifecycle?.currentState == Lifecycle.State.RESUMED) navigate(route)
}

private fun NavController.safePop() {
    if (currentBackStackEntry?.lifecycle?.currentState == Lifecycle.State.RESUMED) popBackStack()
}
